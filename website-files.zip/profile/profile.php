<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" href="thestyle.css">
<link href='http://fonts.googleapis.com/css?family=Raleway:100,200' rel='stylesheet' type='text/css'>
<style type="text/css"></style>
<title>VERVE - Food and Fitness Planner</title>
</head>

<body>
<?php include '../includes/menu.php';?>
<div id="bgg"></div>
<div id="profile">
<div id="subs">
  <img src="../images/sub.jpg" width="151" height="36" /> </div>
<div id="planner">
  <img src="../images/planner.jpg" width="155" height="38" /> </div>
  <div id="recipes">
  <img src="../images/recipe.jpg" height="32" /></div>
  <div id="exer">
   <img src="../images/exercise.jpg" height="33" /></div>
<div id="topInfo">
  <h3>Jane Smith</h3>
  <p>Joined Febuary 9th 2015</p>
</div>
<div id="bigPic"> <img src="../images/Profile_pic.jpg" width="250"/></div>
  <div id="bigPic"> 
  </div>
  <div id="profInfo">
    <p> Username: ilovesport123 </br>
      </br>
      Gender: Female</br>
      </br>
      Age: 20</br>
      </br>
      Location: Bath</br>
      </br>
      Ocupation: Student</br>
      </br>
      Contact: jsmith@gmail.com</br>
      </br>
      Interests: Tennis, Running, TV Series & hanging out with friends</br>
      </br>
      Description: I am a student at the University of Bath. I enjoy exercise and spending time with my friends. Check out my planner for my weekly routine. :) </p>
  </div>
</div></div>
</body>
</html>
