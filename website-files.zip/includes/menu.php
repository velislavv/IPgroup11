
<div id="content">
<div id="top">
  <div id="menu" class="one">
    <ul>
      <li><a href="../home/index.php" class="first">Home</a></li>
      <li><a href="../howto/howto.php">How To Guide</a></li>
    </ul>
  </div>
  <div id="menu" class="two">
    <ul>
      <li><a href="../fitness/fitness.php" class="first">Fitness</a></li>
      <li><a href="../nutrition/nutrition.php">Nutrition</a></li>
    </ul>
  </div>
  <div id="menu" class="three"> <a href="../profile/profile.php" class="two"><img src="../images/log.jpg" height="30" /> </a> <a href="../sign/sign.php"><img src="../images/sing.jpg" height="30" /> </a> </div>
  <img class ="logo" src="../images/Verve_Logo.png" /> 
  </div>
